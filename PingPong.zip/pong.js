"use strict";
document.addEventListener("DOMContentLoaded", init);



function Ball() {
    this.id = "ball";
    this.x = 0;
    this.y = 0;
    this.vx = 40;
    this.vy = 40;
}

function Paddle(id, x) {
    this.id = id;
    this.x = x;
    this.y = 0;
    this.vy = 50;
}


var buttons = {
    p1_up: false,
    p1_down: false,
    p2_up: false,
    p2_down: false,
}


function place_objects(objects) {
    for (let object of objects) {
        let element = document.getElementById(object.id);
        element.style.left = object.x + "px";
        element.style.top = object.y + "px";
    }
}


function new_round(player) {
    ball.x = field.width / 2 - ball.width / 2;
    ball.y = field.height / 2 - ball.height / 2;
    let angle = Math.random() * Math.PI / 2 - Math.PI / 4;
    if (Math.random() < .5) angle += Math.PI;
    ball.vx = Math.cos(angle) * 6;
    ball.vy = Math.sin(angle) * 6;
}



function update() {
    document.addEventListener("keydown", track_player_input);
    document.addEventListener("keyup", track_player_input);

    let body = document.body.getBoundingClientRect();

    //ball
    ball.x += ball.vx;
    ball.y += ball.vy;

    if (ball.y < 0 || ball.y > body.height - 64) {
        ball.vy = -ball.vy;
    }

    if (ball.x < 24 && paddle1.y < ball.y + 32 && ball.y + 32 < paddle1.y + 192) {
        ball.x = paddle1.x + 24;
        ball.vx = - ball.vx;
        if ((buttons.p1_up && ball.vy > 0) || (buttons.p1_down && ball.vy < 0)) {
            ball.vy = - ball.vy;
        }
    }

    if (ball.x + 64 > paddle2.x && paddle2.y < ball.y + 32 && ball.y + 32 < paddle2.y + 192) {
        ball.x = paddle2.x - 64;
        ball.vx = - ball.vx;
        if ((buttons.p2_up && ball.vy > 0) || (buttons.p2_down && ball.vy < 0)) {
            ball.vy = - ball.vy;
        }
    }


    //paddles
    if (paddle1.y > 0 && buttons["p1_up"] == true) {
        paddle1.y += -paddle1.vy;
    }

    if (((paddle1.y + 192) < body.height) && buttons["p1_down"] == true) {
        paddle1.y += +paddle1.vy;
    }

    if (paddle2.y > 0 && buttons["p2_up"] == true) {
        paddle2.y += -paddle1.vy;
    }

    if (((paddle2.y + 192) < body.height) && buttons["p2_down"] == true) {
        paddle2.y += +paddle1.vy;
    }


    place_objects([ball, paddle1, paddle2]);


}

let ball;
let paddle1;
let paddle2;

function init() {
    ball = new Ball();
    paddle1 = new Paddle("paddle1", 0);
    paddle2 = new Paddle("paddle2", document.body.getBoundingClientRect().width - 24);
    setInterval(update, 100);
}


let s = getBoundingClientRect();


function track_player_input(event) {
    if (event.type == "keydown") {
        switch (event.keyCode) {
            case 65: buttons.p1_up = true; break;
            case 90: buttons.p1_down = true; break;
            case 38: buttons.p2_up = true; break;
            case 40: buttons.p2_down = true; break;
        }
    } else if (event.type == "keyup") {
        switch (event.keyCode) {
            case 65: buttons.p1_up = false; break;
            case 90: buttons.p1_down = false; break;
            case 38: buttons.p2_up = false; break;
            case 40: buttons.p2_down = false; break;
        }
    }
}
